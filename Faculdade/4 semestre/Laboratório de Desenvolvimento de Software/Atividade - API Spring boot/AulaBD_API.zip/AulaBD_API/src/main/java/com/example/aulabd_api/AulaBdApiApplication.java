package com.example.aulabd_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaBdApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(AulaBdApiApplication.class, args);
    }

}
