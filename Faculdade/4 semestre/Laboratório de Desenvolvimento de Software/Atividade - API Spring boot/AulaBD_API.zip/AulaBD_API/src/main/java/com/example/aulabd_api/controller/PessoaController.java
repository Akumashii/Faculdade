package com.example.aulabd_api.controller;


import com.example.aulabd_api.model.Pessoa;
import com.example.aulabd_api.repository.PessoaRepository;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pessoas")
public class PessoaController {

    private final PessoaRepository pessoaRepository;

    public PessoaController(PessoaRepository pessoaRepository) {
        super();
        this.pessoaRepository = pessoaRepository;
    }

    @GetMapping
    public List<Pessoa> listar() { return pessoaRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Pessoa> buscar(@PathVariable Long id) {
        if(!pessoaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        Pessoa pessoaExistente = pessoaRepository.findById(id).orElse(null);

        if(pessoaExistente != null) {
            Pessoa pessoaAtualizadoNoBanco = pessoaRepository.save(pessoaExistente);

            return ResponseEntity.ok(pessoaAtualizadoNoBanco);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Pessoa adicionar(@RequestBody Pessoa pessoa){ return pessoaRepository.save(pessoa); }

    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<Void> deletarCliente(@PathVariable Long id){
        if(!pessoaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        //remove o cliente do banco de dados
        pessoaRepository.deleteById(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pessoa> atualizar(@PathVariable Long id, @RequestBody Pessoa pessoaAtualizado){
        if(!pessoaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        Pessoa pessoaExistente = pessoaRepository.findById(id).orElse(null);

        if(pessoaExistente != null) {
            pessoaExistente.setNome(pessoaAtualizado.getNome());
            pessoaExistente.setIdioma(pessoaAtualizado.getIdioma());
            pessoaExistente.setSexo(pessoaAtualizado.getSexo());

            Pessoa pessoaAtualizadoNoBanco = pessoaRepository.save(pessoaExistente);

            return ResponseEntity.ok(pessoaAtualizadoNoBanco);

        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/idioma/{idioma}")
    public ResponseEntity<Pessoa> listarPessoaIdioma(@PathVariable String idioma) {
        if(!pessoaRepository.existsPessoaByIdioma(idioma)) {
            return ResponseEntity.notFound().build();
        }

        Pessoa pessoaExistente = pessoaRepository.findPessoaByIdioma(idioma);

        if(pessoaExistente != null) {
            return ResponseEntity.ok(pessoaExistente);
        } else {
            return ResponseEntity.notFound().build();
        }
    }


}

