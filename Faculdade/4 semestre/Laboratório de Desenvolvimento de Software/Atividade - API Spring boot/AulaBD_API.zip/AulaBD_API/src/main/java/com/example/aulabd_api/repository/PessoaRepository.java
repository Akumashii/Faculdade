package com.example.aulabd_api.repository;

import com.example.aulabd_api.model.Pessoa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface PessoaRepository extends JpaRepository<Pessoa, Long> {


    boolean existsPessoaByIdioma(String idioma);

    Pessoa findPessoaByIdioma(String idioma);
}