/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servidor;

import DAO.ProdutoDAO;
import beans.Produto;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author laboratorio
 */
public class Servidor {
    public static void main(String[] args) {
        int porta = 12345; // use uma constate para a porta (que esteja vazia)
        
        try(ServerSocket servidorSocket = new ServerSocket(porta)){
            System.out.println("Servidor aguardando conexão de porta");
            
            while(true){
                
                try{
                    Socket clienteSocket = servidorSocket.accept();
                    System.out.println("Conexão aceita de "+clienteSocket.getInetAddress());
                    
                    ObjectOutputStream out = new ObjectOutputStream(clienteSocket.getOutputStream());
                    ObjectInputStream in = new ObjectInputStream(clienteSocket.getInputStream());
                   
                    int id = in.readInt();
                    System.out.println("ID recebido: "+id);
                    
                    // simulando a obtenção de um produto a partir do ID
                    ProdutoDAO  pdao = new ProdutoDAO();
                    Produto p = pdao.getProduto(id);
                    System.out.println(p.getNome());
                    
                    out.writeObject(p);
                    out.flush();

                }catch(IOException ex){
                    System.out.println("Erro ao aceitar conexão do cliente");
                }
                
            }
            
        }catch(IOException e){
            System.out.println("Erro ao criar o servidorSocket");
        }
    }
}
