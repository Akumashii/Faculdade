/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.io.Serializable;

/**
 *
 * @author laboratorio
 */
public class Produto implements Serializable {
    private int id;
    private String nome;
    private double preco;
    private int saldo; //quantidade de produto

    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        if(preco>=0)
            this.preco = preco;
        else
            System.out.println("ERRO: Preco Negativo");
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        if(saldo>=0)
            this.saldo = saldo;
        else
            System.out.println("ERRO: Saldo Negativo");
    }
    
    
}
