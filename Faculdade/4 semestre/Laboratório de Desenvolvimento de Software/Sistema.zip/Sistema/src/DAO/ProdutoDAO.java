/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import beans.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class ProdutoDAO {
    private Conexao conexao;
    private Connection conn;

    public ProdutoDAO(){
        this.conexao =  new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir(Produto p){
        try {
            String sql = "INSERT INTO produto(nome, preco, saldo) VALUES (?, ?, ?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setDouble(2, p.getPreco());
            stmt.setInt(3, p.getSaldo());
            
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("ERRO AO INSERIR PRODUTO : "+ex.getMessage());
        }
    }
    
    public List<Produto> getProdutos(){
        try {
            String sql = "SELECT * FROM produto";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            List<Produto> listaCategorias = new ArrayList();
            
            while (rs.next()){
                Produto p = new Produto();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));
                p.setSaldo(rs.getInt("saldo"));
                
                listaCategorias.add(p);
            }
            return listaCategorias;
            
        } catch (SQLException ex) {
            System.out.println("ERRO AO CONSULTAS TODOS OS PRODUTOS : "+ex.getMessage());
            return null;
        }
    }
    
    public Produto getProduto(int id){
        try {
            String sql = "SELECT * FROM produto WHERE id =?";
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Produto p = new Produto();
            rs.first();
            
            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getDouble("preco"));
            p.setSaldo(rs.getInt("saldo"));
            
            return p;            
        } catch (SQLException ex) {
            System.out.println("ERRO AO CONSULTAS PRODUTO PELO ID : "+ex.getMessage());
            return null;        
        }
    }
}
