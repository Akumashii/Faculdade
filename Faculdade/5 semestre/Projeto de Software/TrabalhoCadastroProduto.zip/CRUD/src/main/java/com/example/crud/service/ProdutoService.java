package com.example.crud.service;


import com.example.crud.model.Produto;
import com.example.crud.repository.CategoriaRepository;
import com.example.crud.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {
    private final ProdutoRepository produtoRepository;
    private final CategoriaRepository categoriaRepository;

    public ProdutoService(ProdutoRepository produtoRepository, CategoriaRepository categoriaRepository) {
        this.produtoRepository = produtoRepository;
        this.categoriaRepository = categoriaRepository;
    }

    public void salvar(Produto produto) {
        if(produto.getNome() == null || produto.getNome().isBlank()) {
            throw new RuntimeException("O nome do produto é obrigatório.");
        }
        if(produto.getValor()<= 0) {
            throw new RuntimeException("O valor do produto é obrigatório.");
        }
        if (produto.getCategoria() == null || produto.getCategoria().getId() == null) {
            throw new RuntimeException("Selecione uma categoria para o produto.");
        }

        produtoRepository.save(produto);
    }

    public List<Produto> listar() {
        return produtoRepository.findAll();
    }

    public void deletar(Integer id){
        produtoRepository.deleteById(id);
    }

    public Produto procurarId(Integer id){
        return produtoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado com o ID: " + id));
    }
}
