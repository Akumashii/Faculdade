package com.example.crud.service;

import com.example.crud.model.Categoria;
import com.example.crud.repository.CategoriaRepository;
import com.example.crud.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;
    private final ProdutoRepository produtoRepository;

    public CategoriaService(CategoriaRepository categoriaRepository, ProdutoRepository produtoRepository) {
        this.categoriaRepository = categoriaRepository;
        this.produtoRepository = produtoRepository;
    }

    public void salvar(Categoria categoria) {
        if (categoria.getNome() == null || categoria.getNome().isBlank()) {
            throw new RuntimeException("Nome de Categoria é obrigatório.");
        }

        boolean nomeJaExiste = categoriaRepository.findAll().stream()
                .anyMatch(c -> c.getNome().equalsIgnoreCase(categoria.getNome()) //ignora letra maisucula
                        && !c.getId().equals(categoria.getId()));
        if (nomeJaExiste) {
            throw new RuntimeException("Nome de Categoria já existe no banco de dados.");
        }

        categoriaRepository.save(categoria);
    }

    public List<Categoria> listar() {
        return categoriaRepository.findAll();
    }

    public Categoria procurarId(Integer id){
        return categoriaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoria não encontrada com o ID: " + id));
    }

    public void deletar(Integer id) {
        if (produtoRepository.existsByCategoria_Id(id)) {
            throw new RuntimeException("Categoria possui dependências, não pode ser excluída.");
        }
        categoriaRepository.deleteById(id);
    }
}