package com.example.crud.controller;

import com.example.crud.model.Categoria;

import com.example.crud.service.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Controller
@RequestMapping("/categoria")
public class CategoriaController {

    private final CategoriaService categoriaService;

    public CategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @GetMapping("/formulario")
    public String exibirFormulario(Model model) {
        model.addAttribute("categoria", new Categoria());
        return "categoria/formulario";
    }

    @PostMapping("/salvar")
    public String salvarCategoria(@ModelAttribute Categoria categoria, Model model) {
        categoriaService.salvar(categoria);
        return "redirect:/categoria/listar";
    }

    @GetMapping("/listar")
    public String listarCategorias(Model model) {
        List<Categoria> categoria = categoriaService.listar();
        model.addAttribute("categoria", categoria);
        return "categoria/lista";
    }

    @GetMapping("/editar/{id}")
    public String editarCategoria(@PathVariable Integer id, Model model) {
        Categoria categoria = categoriaService.procurarId(id);
        model.addAttribute("categoria", categoria);
        return "categoria/formulario";
    }

    @GetMapping("/deletar/{id}")
    public String deletarCategoria(@PathVariable Integer id, Model model) {
        categoriaService.deletar(id);
        return "redirect:/categoria/listar";
    }
}