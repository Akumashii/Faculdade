package com.example.crud.controller;

import com.example.crud.model.Produto;
import com.example.crud.service.CategoriaService;
import com.example.crud.service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/produto")
public class ProdutoController {
    private final ProdutoService produtoService;
    private final CategoriaService categoriaService;

    public ProdutoController(ProdutoService produtoService, CategoriaService categoriaService) {
        this.produtoService = produtoService;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/formulario")
    public String exibirFormulario(Model model){
        model.addAttribute("produto", new Produto());
        model.addAttribute("categorias", categoriaService.listar());
        return "produto/formulario";
    }

    @PostMapping("/salvar")
    public String salvarProduto(@ModelAttribute Produto produto){
        //esse objeto que estou recebendo foi enviado através de um model pelo html
        produtoService.salvar(produto);
        return "redirect:/produto/listar"; //toda vez que cadastra um novo entra numa lista
    }

    @GetMapping("/listar")
    public String listarProdutos(Model model) {
        List<Produto> produtos = produtoService.listar();
        model.addAttribute("produtos", produtos);
        return "produto/lista";
    }

    @GetMapping("/deletar/{id}")
    public String deletarProduto(@PathVariable Integer id){
        //PathVariable é um marcador que notifica que o valor está vindo de uma request
        produtoService.deletar(id);
        return "redirect:/produto/listar"; //depois que deleta já retorna pra lista novamente
    }

    @GetMapping("/editar/{id}")
    public String editarProduto(@PathVariable Integer id, Model model){
        Produto produto = produtoService.procurarId(id);
        model.addAttribute("produto", produto);
        model.addAttribute("categorias", categoriaService.listar());
        return "produto/formulario";
    }
}
