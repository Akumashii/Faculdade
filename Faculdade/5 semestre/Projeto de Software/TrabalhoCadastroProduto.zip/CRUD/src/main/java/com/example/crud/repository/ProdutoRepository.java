package com.example.crud.repository;

import com.example.crud.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ProdutoRepository extends JpaRepository<Produto, Integer> {
    //insert, delete, update
    // o JPA já tem oque queremos, precisamos passar a classe que queremos e o tipo da minha classe(seu identificador)

    //posso criar qualquer Query aqui dentro que seja de manipulação

    boolean existsByCategoria_Id(Integer categoriaId);
}
