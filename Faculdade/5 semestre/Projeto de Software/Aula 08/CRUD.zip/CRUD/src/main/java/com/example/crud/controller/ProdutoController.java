package com.example.crud.controller;

import com.example.crud.model.Produto;
import com.example.crud.repository.ProdutoRepository;
import com.example.crud.service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/produto")
public class ProdutoController {
    private final ProdutoRepository produtoRepository;
    private final ProdutoService produtoService;

    public ProdutoController(ProdutoRepository produtoRepository, ProdutoService produtoService) {
        this.produtoRepository = produtoRepository;
        this.produtoService = produtoService;
    }

    @GetMapping("/formulario")
    public String exibirFormulario(Model model){
        model.addAttribute("produto", new Produto());
        return "formulario";
    }

    @PostMapping("/salvar")
    public String salvarProduto(@ModelAttribute Produto produto){
        //esse objeto que estou recebendo foi enviado através de um model pelo html
        produtoService.salvar(produto);
        return "redirect:/produto/listar"; //toda vez que cadastra um novo entra numa lista
    }

    @GetMapping("/listar")
    public String listarProdutos(Model model){
        List<Produto> produtos = produtoRepository.findAll();
        model.addAttribute("produtos", produtos);
        return "lista";
    }

    @GetMapping("/deletar/{id}")
    public String deletarProduto(@PathVariable Integer id){
        //PathVariable é um marcador que notifica que o valor está vindo de uma request
        produtoRepository.deleteById(id);
        return "redirect:/produto/listar"; //depois que deleta já retorna pra lista novamente
    }

    @GetMapping("/editar/{id}")
    public String editarProduto(@PathVariable Integer id, Model model){
        Optional<Produto> produto = produtoRepository.findById(id);
                //.ifPresent( produto -> {});
        model.addAttribute("produto", produto);
        return "formulario";
    }
}
