/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package monitor;

/**
 *
 * @author laboratorio
 */
public class BufferCircular {   
    private final int[] buffer;
    private int front = 0; //Indica a posição do próximo item a ser consumido
    private int rear = 0; //Indica a posição do próximo item a ser produzido
    private int count = 0; //número de itens no buffer
    
    public BufferCircular(int size) {
        buffer = new int[size];
    }
    
    public synchronized void put (int value) throws InterruptedException{
        while(count == buffer.length){
            wait();//buffer cheio, espera até o consumidor consumir algum item e liberar espaço
        }
        buffer[rear] = value;
        rear = (rear+1) % buffer.length;
        
        count++;
        System.out.println("Produzido: "+count); 
        
        notifyAll(); //notifica as threads que estão esperando para consumir
    }

    public synchronized int get() throws InterruptedException{
        while(count == 0){
            wait();//buffer vazio, espera até o produtor produzir algum item
        }
        int result = buffer[front];
        front = (front + 1) % buffer.length;  
        
        System.out.println("Consumido: "+count);
        count--;
        
        notifyAll(); //notifica as threads que estão esperando para produzir
        return result; 
    }
}

