/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package monitor;

/**
 *
 * @author laboratorio
 */
public class Monitor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BufferCircular buffer = new BufferCircular(5);
        Thread threadProdutor = new Thread(new Produtor(buffer));
        Thread threadConsumidor = new Thread(new Consumidor(buffer));
        
        threadProdutor.start();
        threadConsumidor.start();
    }
    
}
