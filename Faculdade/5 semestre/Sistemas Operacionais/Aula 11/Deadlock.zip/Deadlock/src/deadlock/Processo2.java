/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package deadlock;

/**
 *
 * @author laboratorio
 */
public class Processo2 extends Thread{
    private Recurso recurso1;
    private Recurso recurso2;

    public Processo2(Recurso recurso1, Recurso recurso2) {
        this.recurso1 = recurso1;
        this.recurso2 = recurso2;
    }
    /*
    public void run(){
        synchronized (recurso2){
            System.out.println("Processo 2 bloqueou"+recurso2.getNome());
        
            try{
                Thread.sleep(1000);
            }catch(InterruptedException e){}

            synchronized (recurso1){
                System.out.println("Processo 2 bloqueou"+recurso1.getNome());
            }
        }
    }
    */
    
    public void run(){
        synchronized (recurso1){
            System.out.println("Processo 2 bloqueou"+recurso1.getNome());
        
            try{
                Thread.sleep(1000);
            }catch(InterruptedException e){}

            synchronized (recurso2){
                System.out.println("Processo 2 bloqueou"+recurso2.getNome());
            }
        }
    }
}

