/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package deadlock;


public class Deadlock {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Recurso teclado = new Recurso("Teclado");
        Recurso impressora = new Recurso("Impressora");
        
        Processo1 processo1 = new Processo1(teclado, impressora);
        Processo2 processo2 = new Processo2(teclado, impressora);
        
        processo1.start();
        processo2.start();
    }
    
}
