/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThreadNotify;

/**
 *
 * @author laboratorio
 */
public class Principal {
    public static void main(String args[]){
         Mensagem msg = new Mensagem();
         
         Thread t1 = new Thread(() -> {
             msg.esperarMensagem();
         });
         
         Thread t2 = new Thread(() -> {
             try{
                 Thread.sleep(4000);
             }catch(InterruptedException e){
                 e.printStackTrace();
             }
             msg.enviarMensagem();
         });
         
         t1.start();
         t2.start();
    }
}
