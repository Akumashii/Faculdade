/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThreadNotify;

/**
 *
 * @author laboratorio
 */
public class Mensagem {
    private boolean pronta = false;
    
    public synchronized void esperarMensagem(){
        while(!pronta){
            try{
                System.out.println("Thread esperando mensagem...");
                wait(); // espera até alguém chama notify
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }
        System.out.println("Mensagem recebida!");
    }
    
    public synchronized void enviarMensagem(){
        System.out.println("Preparando mensagem..."); 
        pronta = true;
        notify();
        System.out.println("Mensagem enviada!!");
   }
}
