/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThreadDownload;

/**
 *
 * @author laboratorio
 */
public class DownloadThread extends Thread{
    @Override
    public void run(){
        System.out.println("Iniciando Downloado...");

        try{
            Thread.sleep(3000); //tempo para simular tempo de download
        }catch(InterruptedException e){
            e.printStackTrace();
        }
 
        System.out.println("Download Concluído!");
    }     
}
