/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sincronização;

/**
 *
 * @author laboratorio
 */
public class Conta {
    
    private int saldo = 100;
       
    //SECAO CRITICA
    public synchronized void sacar(int valor){
        saldo -= valor;
        System.out.println(Thread.currentThread().getName()+" saldo: "+saldo);

    }
    //SECAO CRITICA
    public synchronized int getSaldo(){
        return saldo;
    }
}
