/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sincronização;

/**
 *
 * @author laboratorio
 */
public class Usuario extends Thread {
    Conta conta;
        
    public Usuario(Conta conta){
        this.conta = conta;
    }
        
    public void run(){
        for (int i = 0; i<10; i++){
            conta.sacar(10);
            //System.out.println(Thread.currentThread().getName()+" saldo: "+conta.getSaldo());
        }
    }
}
