/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sincronização;

/**
 *
 * @author laboratorio
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Conta conta = new Conta();
        
        Usuario u1 = new Usuario(conta);
        Usuario u2 = new Usuario(conta);
        
        u1.start();
        u2.start();
    }
    
}
