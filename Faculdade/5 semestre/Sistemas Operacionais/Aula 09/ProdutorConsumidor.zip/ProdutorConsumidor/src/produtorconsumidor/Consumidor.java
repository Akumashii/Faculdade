/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package produtorconsumidor;

/**
 *
 * @author laboratorio
 */
public class Consumidor implements Runnable{
    private Buffer buffer;

    public Consumidor(Buffer buffer) {
        this.buffer = buffer;
    }
    
    public void run(){
        for (int i=0; i<10; i++){
            int valor = buffer.get();
            //System.out.println("Consumido "+valor);
        }
    }
}
