/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package produtorconsumidor;

/**
 *
 * @author laboratorio
 */
public class ProdutorConsumidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Buffer bufferCompartilhado = new Buffer();
        Thread produtorThread = new Thread(new Produtor(bufferCompartilhado));
        Thread consumidorThread = new Thread(new Consumidor(bufferCompartilhado));
    
        produtorThread.start();
        consumidorThread.start();
    }
    
}
