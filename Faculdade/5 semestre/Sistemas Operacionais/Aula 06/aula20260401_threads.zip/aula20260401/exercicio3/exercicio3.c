/*
3 – Escreva um programa formado por várias threads, que executam um laço de repetição de N interações para incrementar em 1 uma variável compartilhada. Ao término da execução, verifique o valor final da variável compartilhada. 
*/

#include <stdio.h>
#include <pthread.h>

int main(){
	
}
