
/*
1 – Crie um programa com dois threads. As medidas de um terreno retangular devem ser lidas. Um thread deve calcular a área do terreno e outro o perímetro. Todos os resultados obtidos devem ser mostrados ao usuário.
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

typedef struct dimensoes{
	float comprimento;
	float largura;
	float resultado;
} dimensoes;

void *thread_area (void *arg){
	//recebo um arg genérico
	// vale salientar que, um argumento void* ele não tem tipo definido, porém ainda passa o endereço de memória do dado original. "interface universal" 
	dimensoes *d = (dimensoes *)arg;
	
	d->resultado = d->comprimento * d->largura; // usamos '->' já que é ponteiro do struct 
	
	pthread_exit(NULL); // finaliza a thread
}

void *thread_perimetro (void *arg){
	dimensoes *d = (dimensoes *)arg;
	
	d->resultado = 2*d->comprimento + 2*d->largura; 
	
	pthread_exit(NULL); // finaliza a thread
}

int main() {
	struct dimensoes d_area, d_perimetro;

	float comprimento;
	float largura;

	printf("Digite o comprimento do terreno: ");
	scanf("%f", &comprimento);
	printf("Digite a largura do terreno: ");
	scanf("%f", &largura);
	
	d_area.comprimento = d_perimetro.comprimento = comprimento;
	d_area.largura = d_perimetro.largura = largura;
	
	//instanciamento da variavel pthread
	pthread_t area_thread; 
	pthread_t perimetro_thread;
	
	if(pthread_create (&area_thread, NULL, thread_area, (void *)&d_area)){
		//no pthread os parâmetros estão assim:
		//1° endereço do pthread_t area_thread, crio a thread com a variavel area_thread
		//2° NULL, honestamente não entendi esse conceito, configuração do kernel
		//3° thread_area, a função thread que eu quero
		//4° cast void* (thread só recebe void) e o endereço do meu strcut instanciado '&d'
		printf("Erro ao criar a thread.\n");
        	return 1;
        	// validação de erro se deu pau a criar a thread
	}
	
	if(pthread_create (&perimetro_thread, NULL, thread_perimetro, (void *)&d_perimetro)){
		printf("Erro ao criar a thread.\n");
        	return 1;
	}
	
	pthread_join(area_thread, NULL);
   	pthread_join(perimetro_thread, NULL);	
	
	printf("--- Resultado ---\n");
	printf("Área do terreno: %.2f\n", d_area.resultado);
	printf("Perímetro do terreno: %.2f\n", d_perimetro.resultado);
	

	return 0;
}


