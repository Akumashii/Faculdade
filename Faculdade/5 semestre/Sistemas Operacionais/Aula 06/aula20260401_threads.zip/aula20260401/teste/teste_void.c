#include <stdio.h>

int main(){
	void *palavra;
	
	printf(palavra);

	return 0;
}
