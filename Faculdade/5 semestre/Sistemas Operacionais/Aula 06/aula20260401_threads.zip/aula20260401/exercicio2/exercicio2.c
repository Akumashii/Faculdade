#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>

#define N 10

void *thread_loop (void *arg){
	int id = *(int*)arg; //
	for(int i = 0; i < N; i++) {
		printf("Thread %d - Iteração %d\n", id, i+1); //id da thread seguido da iteração
	}
	return NULL;
}

int main(){
	pthread_t thread[10];
	int ids[3] = {1 , 2, 3};
		
	for(int i = 0; i < 10; i++) { //cria as threads
		pthread_create(&thread[i], NULL, thread_loop, &(i));
		pthread_join(thread[i], NULL);
		
	}
	
	//pthread_create(&thread[1], NULL, thread_loop, &ids[1]);
	//pthread_create(&thread[2], NULL, thread_loop, &ids[2]);
	//pthread_create(&thread[3], NULL, thread_loop, &ids[3]);

	for(int i = 0; i < 10; i++) { //da join nelas
	pthread_join(thread[i], NULL);	
	}

	sleep(10);
	return 0;
}
